# Compiled App

Automatically generated on 2026-06-21T17:53:53.400095.

## Running
`pip install -r requirements.txt`
`uvicorn main:app --reload`
