# Compiled App

Automatically generated on 2026-06-21T17:55:11.061393.

## Running
`pip install -r requirements.txt`
`uvicorn main:app --reload`
