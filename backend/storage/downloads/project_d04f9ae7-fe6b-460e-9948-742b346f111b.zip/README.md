# Compiled App

Automatically generated on 2026-06-21T17:53:31.094451.

## Running
`pip install -r requirements.txt`
`uvicorn main:app --reload`
