# Compiled App

Automatically generated on 2026-06-21T17:54:48.945021.

## Running
`pip install -r requirements.txt`
`uvicorn main:app --reload`
