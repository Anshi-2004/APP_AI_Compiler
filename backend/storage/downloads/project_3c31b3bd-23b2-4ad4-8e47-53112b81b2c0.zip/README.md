# Compiled App

Automatically generated on 2026-06-21T17:53:50.202938.

## Running
`pip install -r requirements.txt`
`uvicorn main:app --reload`
