# Compiled App

Automatically generated on 2026-06-21T17:55:09.832510.

## Running
`pip install -r requirements.txt`
`uvicorn main:app --reload`
